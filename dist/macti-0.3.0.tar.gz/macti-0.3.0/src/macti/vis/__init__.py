# Desde el .[nombre del archivo] importa [lista de funciones] 
from .visual import Plotter

# que nombres se exportan si se usa from macti.visual import * 
__all__ = ["Plotter"]
